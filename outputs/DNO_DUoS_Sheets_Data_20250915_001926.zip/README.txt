
DNO DUoS DATA FOR GOOGLE SHEETS
===============================
Created: 2025-09-15 00:19:26

This ZIP file contains CSV files optimized for Google Sheets with the DNO Distribution Use of System (DUoS) charges data.

FILES INCLUDED:
--------------
25 total files in this archive:

MAIN DATA FILES:
- DNO_DUoS_Summary_20250914_195528.csv
- DNO_DUoS_All_Data_20250914_195528.csv
- DNO_Reference_20250914_195528.csv

YEAR-SPECIFIC FILES:
- by_year/Year_2017_20250914_195528.csv
- by_year/Year_2016_20250914_195528.csv
- by_year/Year_2015_20250914_195528.csv
- by_year/Year_2014_20250914_195528.csv
- by_year/Year_2019_20250914_195528.csv
- by_year/Year_2018_20250914_195528.csv
- by_year/Year_2021_20250914_195528.csv
- by_year/Year_2020_20250914_195528.csv
- by_year/Year_2023_20250914_195528.csv
- by_year/Year_2022_20250914_195528.csv
- by_year/Year_2024_20250914_195528.csv
- by_year/Year_2025_20250914_195528.csv
- by_year/Year_2026_20250914_195528.csv

DNO-SPECIFIC FILES:
- by_dno/SSEN_Hydro_20250914_195528.csv
- by_dno/Northern_Powergrid_Yorkshire_20250914_195528.csv
- by_dno/National_Grid_East_Midlands_20250914_195528.csv
- by_dno/Northern_Powergrid_Northeast_20250914_195528.csv
- by_dno/National_Grid_South_West_20250914_195528.csv
- by_dno/Electricity_North_West_20250914_195528.csv
- by_dno/Unknown_20250914_195528.csv
- by_dno/SSEN_Southern_20250914_195528.csv
- by_dno/National_Grid_South_Wales_20250914_195528.csv

UPLOAD INSTRUCTIONS:
------------------
OPTION 1 - UPLOAD TO GOOGLE DRIVE:
1. Go to Google Drive (https://drive.google.com)
2. Create a new folder for the DUoS data
3. Upload this ZIP file to that folder
4. Right-click the ZIP file in Google Drive and select "Open with" > "Google Workspace"
5. The ZIP file will be extracted and CSV files will be available to open with Google Sheets

OPTION 2 - MANUAL IMPORT TO GOOGLE SHEETS:
1. Extract this ZIP file on your computer
2. Go to Google Sheets (https://sheets.new) to create a new spreadsheet
3. Click on File > Import > Upload > Select the CSV files you want to import
4. Choose import options (recommended: "Replace spreadsheet" for the first file)
5. For additional files, use File > Import again but choose "Insert new sheet(s)"

OPTION 3 - USE IN MICROSOFT EXCEL:
1. Extract this ZIP file on your computer
2. Open Microsoft Excel
3. Use File > Open to open each CSV file
4. Save as Excel workbook (.xlsx) if desired

ABOUT THIS DATA:
--------------
This dataset contains Distribution Use of System (DUoS) charges from UK Distribution Network Operators (DNOs).
The data includes:
- Time-based charging bands (Red, Amber, Green)
- Unit rates (p/kWh) for each band
- Fixed charges
- Data organized by DNO and year

For more information about the data structure, see the DNO_Reference CSV file.
